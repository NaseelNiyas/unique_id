const unique = require('./index.js')

console.log(unique.zeroToOne());